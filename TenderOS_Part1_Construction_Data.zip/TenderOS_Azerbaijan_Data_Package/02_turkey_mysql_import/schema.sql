-- MySQL 8+; Turkish reference dataset only. Load UTF-8 CSVs using your ETL/import client.
CREATE DATABASE IF NOT EXISTS tenderos_reference CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tenderos_reference;
CREATE TABLE activities (
 rate_code VARCHAR(100) PRIMARY KEY,
 rate_final_name TEXT,
 rate_unit VARCHAR(100),
 source_year SMALLINT,
 currency CHAR(3)
);
CREATE TABLE resources (
 resource_code VARCHAR(100) PRIMARY KEY,
 resource_name TEXT,
 resource_unit VARCHAR(100)
);
CREATE TABLE activity_resource_lines (
 source_row_id INT PRIMARY KEY,
 rate_code VARCHAR(100),
 row_type VARCHAR(50),
 resource_code VARCHAR(100),
 resource_quantity DECIMAL(24,8) NULL,
 resource_price_per_unit_current DECIMAL(24,8) NULL,
 resource_cost DECIMAL(24,8) NULL,
 total_cost_per_position DECIMAL(24,8) NULL,
 INDEX idx_rate (rate_code), INDEX idx_resource (resource_code), INDEX idx_row_type (row_type)
);
-- No FKs enforced initially: some rows are scope/header lines without resources.
-- Treat all resource prices as TRY and 2025 reference data; never use as official AZN rates.
