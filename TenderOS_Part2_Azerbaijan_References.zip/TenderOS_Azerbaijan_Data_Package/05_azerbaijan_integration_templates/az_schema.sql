-- Azerbaijan-specific data is empty until approved sources are acquired.
-- Never infer official AZN unit rates from TRY or from construction producer price indices.
CREATE DATABASE IF NOT EXISTS tenderos_az CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tenderos_az;
CREATE TABLE az_desn_mapping (id BIGINT AUTO_INCREMENT PRIMARY KEY, turkey_rate_code VARCHAR(100), az_desn_code VARCHAR(120), unit_conversion_factor DECIMAL(24,8), match_status VARCHAR(30) DEFAULT 'unreviewed', official_document_id VARCHAR(255), source_page VARCHAR(50), reviewer VARCHAR(255));
CREATE TABLE az_desn_resource_requirements (id BIGINT AUTO_INCREMENT PRIMARY KEY, az_desn_code VARCHAR(120) NOT NULL, az_resource_code VARCHAR(120) NOT NULL, quantity_per_work_unit DECIMAL(24,8), resource_unit VARCHAR(80), official_document VARCHAR(255), source_page VARCHAR(50), effective_date DATE, review_status VARCHAR(30) DEFAULT 'unreviewed');
CREATE TABLE az_official_resource_prices (id BIGINT AUTO_INCREMENT PRIMARY KEY, az_resource_code VARCHAR(120) NOT NULL, resource_type VARCHAR(50), unit VARCHAR(80), price_azn DECIMAL(24,8), price_date DATE, region VARCHAR(120), issuing_authority VARCHAR(255), source_document VARCHAR(255), source_page VARCHAR(50), approval_status VARCHAR(30) DEFAULT 'unverified');
CREATE TABLE az_market_price_observations (id BIGINT AUTO_INCREMENT PRIMARY KEY, resource_name TEXT, unit VARCHAR(80), price_azn DECIMAL(24,8), supplier VARCHAR(255), source_url TEXT, observed_date DATE, region VARCHAR(120), official_approved BOOLEAN DEFAULT FALSE);
