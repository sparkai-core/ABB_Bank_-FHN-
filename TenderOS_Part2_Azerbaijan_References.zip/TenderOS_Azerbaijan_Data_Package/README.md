# TenderOS — Azerbaijan Data Integration Kit

## What is usable now
- Turkish 2025 work-item / resource quantity / unit-cost reference (TRY), raw and normalized MySQL files.
- Azerbaijan regulatory and normative *catalogues*, including the 2026 catalogue, plus E-QANUN regulations.
- Azerbaijan official construction price *indices* (not unit rates), 2026 bulletin/yearbook and annual index CSV.
- Working reference-only prototype ZIP from the earlier build.
- Empty, structured Azerbaijan mapping / DESN quantity / official AZN price / BOQ templates and SQL schema.

## What is NOT in this package
- Full Azerbaijan DESN activity-to-resource consumption tables.
- Current officially approved AZN material, wage or machinery rate books.
- Approved mapping between Turkish construction work items and Azerbaijan DESN.
- Permission for commercial reuse of the Turkish reference dataset.

## Safe use for Azerbaijan
1. Import Turkey reference tables into tenderos_reference; label ALL estimates as Turkish 2025 reference in TRY.
2. Ingest official Azerbaijan price-index CSV as an index time series, not as unit price.
3. Use Azerbaijan normative catalogues to index DESN identifiers, not to invent quantities.
4. Fill mapping template only with reviewer-approved, sourced equivalences; verify unit conversions.
5. Import official AZN resource rates only when dated, approved source documents are obtained.
6. Keep Azerbaijan official compliance status as UNVERIFIED / DISABLED until both approved norms and rates exist.
7. Market observations are informational and cannot substitute for official approved rates.

## Licensing
Read raw ZIP LICENSE-DATA.txt before using DDC in commercial software. Also check redistribution/reproduction rights for included official PDFs. This package is a research/integration handoff, not a grant of redistribution rights.

## Folder guide
01_turkey_reference_raw: original six-file source archive
02_turkey_mysql_import: source normalized CSVs, SQL, data quality, and earlier import archive
03_azerbaijan_official_references: regulation and normative catalogues
04_azerbaijan_statistical_indices: index time series, bulletin, yearbook
05_azerbaijan_integration_templates: empty official-data templates and AZ schema
06_prototype: reference-only local app
