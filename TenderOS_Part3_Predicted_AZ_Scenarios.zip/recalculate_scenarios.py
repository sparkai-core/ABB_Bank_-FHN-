import argparse,csv
p=argparse.ArgumentParser();p.add_argument('--fx',type=float,required=True);p.add_argument('--low',type=float,default=.8);p.add_argument('--base',type=float,default=1.0);p.add_argument('--high',type=float,default=1.2);p.add_argument('--input',default='predicted_activity_rates.csv');p.add_argument('--output',default='revised_activity_rates.csv');a=p.parse_args()
if min(a.fx,a.low,a.base,a.high)<=0:raise ValueError('Positive assumptions required')
with open(a.input,encoding='utf-8-sig',newline='') as src,open(a.output,'w',encoding='utf-8-sig',newline='') as dst:
 r=csv.DictReader(src);w=csv.DictWriter(dst,fieldnames=r.fieldnames);w.writeheader()
 for x in r:
  x['scenario_fx_azn_per_try']=a.fx
  if x['source_total_try']:
   for name,m in [('low',a.low),('base',a.base),('high',a.high)]:x['predicted_unit_azn_'+name]=round(float(x['source_total_try'])*a.fx*m,4)
  w.writerow(x)
print('Saved',a.output)
