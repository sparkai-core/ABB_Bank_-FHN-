# Part 3 — Synthetic Azerbaijan Scenarios (NOT OFFICIAL DATA)

This package is **predicted/illustrative** and MUST NOT be used as an official Azerbaijan DESN reference, government-approved AZN price list, tender rejection criterion, or market quotation.

## Contents
- `predicted_activity_rates.csv`: 22,704 Turkish activity codes with synthetic AZN low/base/high unit-rate scenarios.
- `predicted_resource_lines.csv`: all 110,061 original lines with synthetic AZN resource prices and costs where source prices/costs exist.
- `scenario_config.json`: assumptions.
- `example_boq_scenario.csv`: demo BOQ.
- `recalculate_scenarios.py`: local reproducible recalculation with your own FX and multipliers.

## Method and limits
2025 Turkish TRY amounts are multiplied by an **arbitrary, explicitly fictional demonstration FX of 0.05 AZN/TRY**, then by low/base/high factors 0.8/1.0/1.2. **These are NOT current exchange rates, Azerbaijan prices, or statistically trained predictions.** Turkish work norms may not apply to Azerbaijani construction. No cross-country DESN mapping is inferred. The original quantities are Turkish reference quantities and are not approved DESN consumption norms. Missing source amounts remain missing. `is_official_azerbaijan=FALSE` on every row.

## Production safeguards
Keep this dataset in a separate `scenario_reference` namespace; never mark as `official` or use to certify tenders. Require a reviewer and original provenance for all comparisons. Replace assumptions with independently sourced local supplier prices and approved DESN data. Verify source dataset's non-commercial licensing.

## Recalculate
`python recalculate_scenarios.py --fx 0.05 --low 0.8 --base 1.0 --high 1.2 --input predicted_activity_rates.csv --output revised_activity_rates.csv`

Note: This script recalculates activity scenario columns from original TRY totals, not from previously predicted AZN columns.
